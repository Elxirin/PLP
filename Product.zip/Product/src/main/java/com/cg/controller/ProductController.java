package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bean.Product;
import com.cg.service.ProductServiceImpl;

/*
@CrossOrigin(origins = "http://localhost:4200")*/
@RestController
public class ProductController {
	
	@Autowired
	private ProductServiceImpl productServiceImpl;
	
//	@RequestMappingue = "/products", method = RequestMethod.GET)
	@RequestMapping("/products")
	public List<Product> findAllDetails() {
		return productServiceImpl.getAllProducts();
	}
}

